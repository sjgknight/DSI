# Platform

|field    |value                        |
|:--------|:----------------------------|
|version  |R version 3.6.1 (2019-07-05) |
|os       |macOS Catalina 10.15.2       |
|system   |x86_64, darwin15.6.0         |
|ui       |X11                          |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|ctype    |en_US.UTF-8                  |
|tz       |America/New_York             |
|date     |2020-02-12                   |

# Dependencies

|package |old    |new    |Δ  |
|:-------|:------|:------|:--|
|learnr  |0.10.0 |0.10.1 |*  |

# Revdeps

