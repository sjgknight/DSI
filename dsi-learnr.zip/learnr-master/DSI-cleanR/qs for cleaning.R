1.	How many rows should the North American country that isn’t Canada have?  I make 46047 after all merges and a scan
2.	Where has the most students? (Are the first answers you find plausible?)  University of Cincinnati comes up with 3,198,523,096 a quick google indicates it should be 26,608. The next ones down are also ridiculous (although CalState system is v large). Sorting on num students is probably the best bet here (excluding the very large values).
3.	Which college is the most recently (uhum) established one?  Skidmore & Concordia clearly wrong, there are a bunch in 2011

1.	How many rows should the North American country that isn’t Canada have?
  2.	Where has the most students? (Are the first answers you find plausible?)
3.	Which college is the most recently (uhum) established one? 
  4.	Where has the largest endowment for the smallest number of faculty?
  