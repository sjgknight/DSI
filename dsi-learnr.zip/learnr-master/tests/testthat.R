
if (requireNamespace("testthat")) {
  library(testthat)
  library(learnr)

  test_check("learnr")
}
