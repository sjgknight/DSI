---
name  : Ask a Question
about : The issue tracker is not for general help questions -- please ask general learnr help questions at https://community.rstudio.com/c/shiny.
---

The issue tracker is not for questions. If you have a question, please feel free to ask learnr help questions on our community site under the teaching category, at https://community.rstudio.com/c/teaching.  Please tag your post with a learnr tag to increase visibility.

Open a new post [here (teaching `category` with `learnr` tag)](https://community.rstudio.com/new-topic?title=&category_id=13&tags=learnr&body=%0A%0A%0A%20%20--------%0A%20%20%0A%20%20%3Csup%3EReferred%20here%20by%20%60learnr%60%27s%20GitHub%3C/sup%3E%0A&u=barret).
