options(tutorial.exercise.timelimit = 10)

```{r setup, include=FALSE}
tutorial_options(exercise.timelimit = 10)
```

```{r exercise1, exercise=TRUE, exercise.timelimit=10}
```