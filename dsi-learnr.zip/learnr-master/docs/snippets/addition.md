```{r addition, exercise=TRUE}
1 + 1
```