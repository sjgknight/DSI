```{r setup, include=FALSE}
library(learnr)
tutorial_options(exercise.completion = FALSE)
```

```{r histogram-plot, exercise=TRUE, exercise.completion=TRUE}

```