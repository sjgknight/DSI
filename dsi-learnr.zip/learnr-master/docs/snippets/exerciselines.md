```{r add-function, exercise=TRUE, exercise.lines=15}
# Write a function to add two numbers together
add_numbers <- function(a, b) {
  
}
```