```r
learnr::run_tutorial("hello", package = "learnr")
learnr::run_tutorial("slidy", package = "learnr")
```