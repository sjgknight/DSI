```r
checker <- function(
  label,
  user_code,
  solution_code,
  check_code,
  envir_result,
  evaluate_result,
  envir_prep,
  ...
) {
  list(message = "Great job!", correct = TRUE, location = "append")
}
```
