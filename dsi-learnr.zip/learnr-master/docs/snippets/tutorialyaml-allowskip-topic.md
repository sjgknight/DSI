
### Exercise 2 {data-allow-skip=TRUE}
