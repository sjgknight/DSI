```{r setup, include=FALSE}
library(learnr)
gradethis::gradethis_setup()
```

* Submit `1+1` to receive a correct grade.

```{r exercise1, exercise = TRUE}

```

```{r exercise1-solution}
1+1
```
 
```{r exercise1-code-check}
grade_code()
```
