```{r filter, exercise=TRUE}
# filter the flights table to include only United and American flights
flights
```

<div id="filter-hint">
**Hint:** You may want to use the dplyr `filter` function.
</div>
