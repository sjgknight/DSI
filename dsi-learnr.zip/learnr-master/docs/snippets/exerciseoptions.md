```{r setup, include=FALSE}
library(learnr)
tutorial_options(exercise.timelimit = 60)
```

```{r addition, exercise=TRUE, exercise.timelimit = 60}
1 + 1
```