---
title: "Hello, Tutorial!"
output: learnr::tutorial
runtime: shiny_prerendered
---

```{r setup, include=FALSE}
library(learnr)
```

This code computes the answer to one plus one, change it so it computes two plus two:

```{r addition, exercise=TRUE}
1 + 1
```